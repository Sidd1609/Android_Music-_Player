package com.ldt.musicr.ui.widget.navigate;

public interface BackPressable {
    boolean onBackPressed();
}
