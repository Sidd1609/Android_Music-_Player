package com.ldt.musicr.ui.widget;

import android.content.Context;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import android.util.AttributeSet;
import android.widget.FrameLayout;

/**
 * Created by trung on 10/2/2017.
 */

public class RootScreen_FrameLayout extends FrameLayout {
    public RootScreen_FrameLayout(@NonNull Context context) {
        super(context);
    }

    public RootScreen_FrameLayout(@NonNull Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
    }

    public RootScreen_FrameLayout(@NonNull Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
    }
}
